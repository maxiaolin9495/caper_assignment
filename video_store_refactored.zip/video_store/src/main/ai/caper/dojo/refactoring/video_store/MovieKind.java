package ai.caper.dojo.refactoring.video_store;

public enum MovieKind {
    CHILDREN,
    REGULAR,
    NEW_RELEASE
}
