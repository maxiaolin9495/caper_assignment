package ai.caper.dojo.refactoring.video_store;

public class Movie {

    private final String _title;
    private MovieKind _priceCode;

    public Movie(String title, MovieKind movieKind) {
        _title = title;
        _priceCode = movieKind;
    }

    public MovieKind getPriceCode() {
        return _priceCode;
    }

    public void setPriceCode(MovieKind arg) {
        _priceCode = arg;
    }

    public String getTitle (){
        return _title;
    };
}
