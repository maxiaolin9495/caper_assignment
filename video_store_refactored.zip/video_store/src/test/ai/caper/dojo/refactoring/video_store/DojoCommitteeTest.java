/* DO NOT MODIFY THIS FILE! */
package ai.caper.dojo.refactoring.video_store;

import org.junit.Assert;
import org.junit.Test;

import static ai.caper.dojo.refactoring.video_store.MovieKind.CHILDREN;
import static ai.caper.dojo.refactoring.video_store.MovieKind.NEW_RELEASE;
import static ai.caper.dojo.refactoring.video_store.MovieKind.REGULAR;

public class DojoCommitteeTest {
    @Test
    public void testCreateCustomer() {
        Customer customer = new Customer("Jack");
        Assert.assertEquals("Jack", customer.getName());
    }

    @Test
    public void testStatement() {
        Movie harryPotter = new Movie("Harry Potter", NEW_RELEASE);
        Movie starWars = new Movie("Star Wars", REGULAR);
        Movie SpongeBobSquarePants = new Movie("SpongeBob SquarePants", CHILDREN);

        Customer customer = new Customer("Timmy");

        Rental rentalHarryPotter = new Rental(harryPotter, 3);
        Rental rentalStarWars = new Rental(starWars, 5);
        Rental rentalSpongeBobSquarePants = new Rental(SpongeBobSquarePants, 1);

        customer.addRental(rentalHarryPotter);
        customer.addRental(rentalStarWars);
        customer.addRental(rentalSpongeBobSquarePants);

        Assert.assertEquals("Rental Record for Timmy\n" +
                "\tHarry Potter\t9.0\n" +
                "\tStar Wars\t6.5\n" +
                "\tSpongeBob SquarePants\t1.5\n" +
                "Amount owed is 17.0\n" +
                "You earned 4 frequent renter points",
                customer.statement()
        );
    }
}
